<?php
    define('HTML5_DEBUG', true);
?>