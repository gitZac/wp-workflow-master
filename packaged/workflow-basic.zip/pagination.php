<!-- pagination -->
<div class="pagination">
	<?php workflow-basicwp_pagination(); ?>
</div>
<!-- /pagination -->
