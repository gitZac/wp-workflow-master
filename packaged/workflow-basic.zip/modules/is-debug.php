<?php
    define('workflow-basic_DEBUG', true);
?>